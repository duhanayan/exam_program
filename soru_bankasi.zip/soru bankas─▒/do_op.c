#include <unistd.h>
#include <stdio.h>
int ft_atoi(char *str)
{
    int sayi = 0, i = 0;
    while(str[i] != '\0')
    {
        sayi = (str[i] - '0') + (sayi * 10);
        i++;
    }
    return (sayi);
}

void ft_putnbr(int x)
{
    if(x < 0)
    {
        write(1, "-", 1);
        x *= -1;
    }
    if(x <= 9)
        write(1, &"0123456789"[x], 1);
    else
    {
        ft_putnbr(x / 10);
        ft_putnbr(x % 10);
    }
}

int main(int argc, char **argv)
{
    int x;
    int y;
    if(argc == 4)
    {
        x = ft_atoi(argv[1]);
        y = ft_atoi(argv[3]);
        if(argv[2][0] == '+')
            ft_putnbr(x+y);
        else if(argv[2][0] == '-')
            ft_putnbr(x-y);
    }
    write(1, "\n", 1);
    return 5;
}
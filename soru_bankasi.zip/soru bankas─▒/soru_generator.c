#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include<time.h>

int ft_atoi(char *str)
{
    int sayi = 0, i = 0;
    while(str[i] != '\0')
    {
        sayi = (str[i] - '0') + (sayi * 10);
        i++;
    }
    printf("sayi: %d\n", sayi);
    return (sayi);
}

int main(int argc, char **argv)
{
    if(argc != 2)
    {
        printf("Lutfen Seviye Giriniz. (0-4)\n");
        return (0);
    }
    int seviye = ft_atoi(argv[1]);
    int sor[5][15];
    sor[0][0] = open("sorular/level0/aff_a/subject.en.txt", O_RDONLY);
    sor[0][1] = open("sorular/level0/aff_first_param/subject.en.txt", O_RDONLY);
    sor[0][2] = open("sorular/level0/aff_last_param/subject.en.txt", O_RDONLY),
    sor[0][3] = open("sorular/level0/aff_z/subject.en.txt", O_RDONLY),
    sor[0][4] = open("sorular/level0/maff_alpha/subject.en.txt", O_RDONLY),
    sor[0][5] = open("sorular/level0/only_z/subject.en.txt", O_RDONLY),
    sor[0][6] = open("sorular/level0/strlen_sh/subject.en.txt", O_RDONLY);
    sor[0][7] = 0;
    sor[0][8] = 0;
    sor[0][9] = 0;
    sor[0][10] = 0;
    sor[0][11] = 0;
    sor[0][12] = 0;
    sor[0][13] = 0;
    sor[0][14] = 0;

    sor[1][0] = open("./sorular/level1/first_word/subject.en.txt", O_RDONLY);
    sor[1][1] = open("./sorular/level1/ft_countdown/subject.en.txt", O_RDONLY),
    sor[1][2] = open("./sorular/level1/ft_print_numbers/subject.en.txt", O_RDONLY),
    sor[1][3] = open("./sorular/level1/ft_putstr/subject.en.txt", O_RDONLY),
    sor[1][4] = open("./sorular/level1/ft_strcpy/subject.en.txt", O_RDONLY),
    sor[1][5] = open("./sorular/level1/ft_strlen/subject.en.txt", O_RDONLY),
    sor[1][6] = open("./sorular/level1/ft_swap/subject.en.txt", O_RDONLY);
    sor[1][7] = open("./sorular/level1/hello/subject.en.txt", O_RDONLY);
    sor[1][8] = open("./sorular/level1/repeat_alpha/subject.en.txt", O_RDONLY),
    sor[1][9] = open("./sorular/level1/rev_print/subject.en.txt", O_RDONLY),
    sor[1][10] = open("./sorular/level1/rot_13/subject.en.txt", O_RDONLY),
    sor[1][11] = open("./sorular/level1/rotone/subject.en.txt", O_RDONLY),
    sor[1][12] = open("./sorular/level1/search_and_replace/subject.en.txt", O_RDONLY),
    sor[1][13] = open("./sorular/level1/ulstr/subject.en.txt", O_RDONLY);
    sor[1][14] = 0;

    sor[2][0] = open("./sorular/level2/alpha_mirror/subject.en.txt", O_RDONLY);
    sor[2][1] = open("./sorular/level2/do_op/subject.en.txt", O_RDONLY),
    sor[2][2] = open("./sorular/level2/ft_atoi/subject.en.txt", O_RDONLY),
    sor[2][3] = open("./sorular/level2/ft_strcmp/subject.en.txt", O_RDONLY),
    sor[2][4] = open("./sorular/level2/ft_strdup/subject.en.txt", O_RDONLY),
    sor[2][5] = open("./sorular/level2/ft_strrev/subject.en.txt", O_RDONLY),
    sor[2][6] = open("./sorular/level2/inter/subject.en.txt", O_RDONLY);
    sor[2][7] = open("./sorular/level2/is_power_of_2/subject.en.txt", O_RDONLY);
    sor[2][8] = open("./sorular/level2/last_word/subject.en.txt", O_RDONLY),
    sor[2][9] = open("./sorular/level2/max/subject.en.txt", O_RDONLY),
    sor[2][10] = open("./sorular/leve2/print_bits/subject.en.txt", O_RDONLY),
    sor[2][11] = open("./sorular/level2/reverse_bits/subject.en.txt", O_RDONLY),
    sor[2][12] = open("./sorular/level2/swap_bits/subject.en.txt", O_RDONLY),
    sor[2][13] = open("./sorular/level2/union/subject.en.txt", O_RDONLY);
    sor[2][14] = open("./sorular/level2/wdmatch/subject.en.txt", O_RDONLY);

    sor[3][0] = open("./sorular/level3/add_prime_sum/subject.en.txt", O_RDONLY);
    sor[3][1] = open("./sorular/level3/epur_str/subject.en.txt", O_RDONLY),
    sor[3][2] = open("./sorular/level3/expand_str/subject.en.txt", O_RDONLY),
    sor[3][3] = open("./sorular/level3/ft_atoi_base/subject.en.txt", O_RDONLY),
    sor[3][4] = open("./sorular/level3/ft_list_size/subject.en.txt", O_RDONLY),
    sor[3][5] = open("./sorular/level3/ft_range/subject.en.txt", O_RDONLY),
    sor[3][6] = open("./sorular/level3/ft_rrange/subject.en.txt", O_RDONLY);
    sor[3][7] = open("./sorular/level3/hidenp/subject.en.txt", O_RDONLY);
    sor[3][8] = open("./sorular/level3/lcm/subject.en.txt", O_RDONLY),
    sor[3][9] = open("./sorular/level3/paramsum/subject.en.txt", O_RDONLY),
    sor[3][10] = open("./sorular/level3/pgcd/subject.en.txt", O_RDONLY),
    sor[3][11] = open("./sorular/level3/print_hex/subject.en.txt", O_RDONLY),
    sor[3][12] = open("./sorular/level3/rstr_capitalizer/subject.en.txt", O_RDONLY),
    sor[3][13] = open("./sorular/level3/str_capitalizer/subject.en.txt", O_RDONLY);
    sor[3][14] = open("./sorular/level3/tab_mult/subject.en.txt", O_RDONLY);

    sor[4][0] = open("./sorular/level4/fprime/subject.en.txt", O_RDONLY);
    sor[4][1] = open("./sorular/level4/ft_itoa/subject.en.txt", O_RDONLY),
    sor[4][2] = open("./sorular/level4/ft_list_foreach/subject.en.txt", O_RDONLY),
    sor[4][3] = open("./sorular/level4/ft_list_remove_if/subject.en.txt", O_RDONLY),
    sor[4][4] = open("./sorular/level4/ft_split/subject.en.txt", O_RDONLY),
    sor[4][5] = open("./sorular/level4/rev_wstr/subject.en.txt", O_RDONLY),
    sor[4][6] = open("./sorular/level4/rostring/subject.en.txt", O_RDONLY);
    sor[4][7] = open("./sorular/level4/sort_int_tab/subject.en.txt", O_RDONLY);
    sor[4][8] = open("./sorular/level4/sort_list/subject.en.txt", O_RDONLY),
    sor[4][9] = 0;
    sor[4][10] = 0;
    sor[4][11] = 0;
    sor[4][12] = 0;
    sor[4][13] = 0;
    sor[4][14] = 0;

    char buff;
    char sorular[9999];
    int ret = 1;
    int j = 0;
    int k = 0;
    srand(time(0));
    while(1)
    {
        k = rand() % (sizeof(sor[seviye]) / sizeof(int));
        if(sor[seviye][k])
            break;
    }
    while(ret > 0)
    {
        ret = read(sor[seviye][k], &buff, 1);
        if(ret <= 0)
        {
            break;
        }
        sorular[j] = buff;
        j++;
    }
    sorular[j] = '\0'; 
    printf("%s\n", sorular);
    return (0);
}